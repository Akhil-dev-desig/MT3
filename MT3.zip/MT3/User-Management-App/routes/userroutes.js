var express = require('express');
var mongoose = require('mongoose');
const router = express.Router();
let User = require('../model/user.model');
var app = express();

var dbURL='mongodb://localhost:27017/usersdb';

mongoose.connect(dbURL, { useNewUrlParser: true });
let db = mongoose.connection;

//Connecting database
db.once('open',function(){
    console.log('Connection Open With Mongodb Server');
})

//Checking for database
db.on('error',function(err){
    console.log('Error:'+err.stack);
})

//Get operation
router.get('/',function(req,res){
    User.find(function(err,results){
        if(err){
            res.send(err.stack)
            return;
        }
        res.render('index.pug',{users:results});
    });
});

//rendering to the addUser
router.get('/add',function(req,res){
    res.render('addUser',{date:new Date()}
);
})


//POST operation
router.post('/addUser',(req,res)=>{
 let user=new User();
 user._id=req.body._id;
 user.userName=req.body.userName;
 user.userEmail=req.body.userEmail;
 user.userAddress=req.body.userAddress;

 user.save(function(err){
     if(err){
         console.log(err.stack);
         return;
     }
     console.log('Saved to database');
     res.redirect('/');
 });
});

//Delete operation

router.post('/deleteUser/:id',function(req,res){
    let queryDelete = { _id: req.params.id };
    User.deleteOne(queryDelete,function(err){
        if(err){
            console.log(err.stack);
            return;
        }
        console.log('Document is Deleted')
        res.redirect('/');
    });
});
module.exports=router;