//1.importing modules
var express=require('express');
var routeUsers=require('./routes/userroutes');
const bodyParser=require('body-parser');

var app=express();

//2.Configuring view engine
app.set('view engine', 'pug');
app.set('views', './views');
app.use(express.static('./public'));

//4.Adding middlewares
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


//5.Configuring routing
app.use('/',routeUsers);
app.listen(3000, () => {
    console.log('Server Started on port 3000');
})