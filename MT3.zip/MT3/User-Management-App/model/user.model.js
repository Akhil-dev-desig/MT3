//importing mongoose module
const mongoose=require('mongoose');

//creating object for Schema
const Schema=mongoose.Schema

//creating  our schema with uor validations
let User=new Schema({
    _id:String,
    userName:String,
    userEmail:String,
    userAddress:String
})

//Exporting Schema
module.exports=mongoose.model('Users',User);